const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  phone: String,
  education: String,
  experience: String,
  skills: String,
  summary: String,
  projects: [String],
  achievements: [String]
});

module.exports = mongoose.model('Employee', employeeSchema);
