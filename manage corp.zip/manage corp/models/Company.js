const mongoose = require('mongoose');


const companySchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  jobPost: {
    title: String,
    location: String,
    experience: String,
    skills: String,
    description: String
  },
  projects: [String],
  achievements: [String]
});

module.exports = mongoose.model('Company', companySchema);
