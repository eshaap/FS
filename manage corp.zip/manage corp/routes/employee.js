const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');

// Registration form
router.get('/register', (req, res) => {
  res.render('employee/register');
});

// Register employee
router.post('/register', async (req, res) => {
  const { name, email, password, phone, education, experience, skills, summary, projects, achievements } = req.body;
  await Employee.create({
    name,
    email,
    password,
    phone,
    education,
    experience,
    skills,
    summary,
    projects: projects ? projects.split('\n').map(p => p.trim()).filter(p => p) : [],
    achievements: achievements ? achievements.split('\n').map(a => a.trim()).filter(a => a) : []
  });
  res.redirect('/employee/login');
});

// Login form
router.get('/login', (req, res) => {
  res.render('employee/login');
});

// Login logic
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await Employee.findOne({ email, password });
  if (user) {
    req.session.user = user;
    res.redirect('/employee/dashboard');
  } else {
    res.render('employee/login', { error: 'Invalid credentials' });
  }
});

// Dashboard
router.get('/dashboard', (req, res) => {
  if (!req.session.user) return res.redirect('/employee/login');
  res.render('employee/dashboard', { user: req.session.user });
});


// Resume view
router.get('/resume', (req, res) => {
  if (!req.session.user) return res.redirect('/employee/login');
  res.render('employee/resume', { user: req.session.user });
});

// Edit profile form
router.get('/edit', (req, res) => {
  if (!req.session.user) return res.redirect('/employee/login');
  res.render('employee/edit', { user: req.session.user });
});

// Handle profile edit
router.post('/edit', async (req, res) => {
  if (!req.session.user) return res.redirect('/employee/login');
  const { name, email, phone, education, experience, skills, summary, password, projects, achievements } = req.body;
  const update = {
    name,
    email,
    phone,
    education,
    experience,
    skills,
    summary
  };
  // Only update password if provided
  if (password && password.trim() !== '') {
    update.password = password;
  }
  // Parse projects/achievements from textarea (split by newlines)
  update.projects = projects ? projects.split('\n').map(p => p.trim()).filter(p => p) : [];
  update.achievements = achievements ? achievements.split('\n').map(a => a.trim()).filter(a => a) : [];
  const user = await Employee.findByIdAndUpdate(req.session.user._id, update, { new: true });
  req.session.user = user;
  res.redirect('/employee/resume');
});

module.exports = router;
