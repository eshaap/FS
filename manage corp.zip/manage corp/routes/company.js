const express = require('express');
const router = express.Router();
const Company = require('../models/Company');
const Employee = require('../models/Employee');

// Registration form
router.get('/register', (req, res) => {
  res.render('company/register');
});

// Register company
router.post('/register', async (req, res) => {
  const { name, email, password, projects, achievements } = req.body;
  const company = {
    name,
    email,
    password,
    projects: projects ? projects.split('\n').map(p => p.trim()).filter(p => p) : [],
    achievements: achievements ? achievements.split('\n').map(a => a.trim()).filter(a => a) : []
  };
  await Company.create(company);
  res.redirect('/company/login');
});
// Edit company profile form
router.get('/edit', (req, res) => {
  if (!req.session.company) return res.redirect('/company/login');
  res.render('company/edit', { company: req.session.company });
});

// Handle company profile edit
router.post('/edit', async (req, res) => {
  if (!req.session.company) return res.redirect('/company/login');
  const { name, email, password, projects, achievements } = req.body;
  const update = {
    name,
    email
  };
  if (password && password.trim() !== '') {
    update.password = password;
  }
  update.projects = projects ? projects.split('\n').map(p => p.trim()).filter(p => p) : [];
  update.achievements = achievements ? achievements.split('\n').map(a => a.trim()).filter(a => a) : [];
  const company = await Company.findByIdAndUpdate(req.session.company._id, update, { new: true });
  req.session.company = company;
  res.redirect('/company/dashboard');
});

// Login form
router.get('/login', (req, res) => {
  res.render('company/login');
});

// Login logic
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const company = await Company.findOne({ email, password });
  if (company) {
    req.session.company = company;
    res.redirect('/company/dashboard');
  } else {
    res.render('company/login', { error: 'Invalid credentials' });
  }
});

// Dashboard
router.get('/dashboard', (req, res) => {
  if (!req.session.company) return res.redirect('/company/login');
  res.render('company/dashboard', { company: req.session.company });
});

// Post job requirements
router.get('/post', (req, res) => {
  if (!req.session.company) return res.redirect('/company/login');
  res.render('company/post');
});


router.post('/post', async (req, res) => {
  if (!req.session.company) return res.redirect('/company/login');
  const { title, location, experience, skills, description } = req.body;
  await Company.findByIdAndUpdate(req.session.company._id, {
    jobPost: { title, location, experience, skills, description }
  });
  res.redirect('/company/search');
});

// Search for candidates

router.get('/search', async (req, res) => {
  if (!req.session.company) return res.redirect('/company/login');
  const company = await Company.findById(req.session.company._id);
  let query = {};
  if (company.jobPost && company.jobPost.skills) {
    query.skills = { $regex: company.jobPost.skills + '', $options: 'i' };
  }
  if (company.jobPost && company.jobPost.experience) {
    query.experience = { $regex: company.jobPost.experience + '', $options: 'i' };
  }
  // You can add more fields like location if you add it to Employee model
  const candidates = await Employee.find(query);
  res.render('company/search', { candidates });
});

module.exports = router;
