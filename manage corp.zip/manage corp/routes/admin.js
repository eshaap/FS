const express = require('express');
const router = express.Router();
const Admin = require('../models/Admin');
const Employee = require('../models/Employee');
const Company = require('../models/Company');

// Admin login
router.get('/login', (req, res) => {
  res.render('admin/login');
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  // Allow hardcoded default admin login
  if (username === 'admin' && password === 'admin') {
    req.session.admin = { username: 'admin' };
    return res.redirect('/admin/dashboard');
  }
  // Fallback to DB check for any other admin
  const admin = await Admin.findOne({ username, password });
  if (admin) {
    req.session.admin = admin;
    res.redirect('/admin/dashboard');
  } else {
    res.render('admin/login', { error: 'Invalid credentials' });
  }
});

// Admin dashboard
router.get('/dashboard', async (req, res) => {
  if (!req.session.admin) return res.redirect('/admin/login');
  const employees = await Employee.find();
  const companies = await Company.find();
  res.render('admin/dashboard', { employees, companies });
});

module.exports = router;
