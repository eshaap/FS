
# Manage Corp

A modern full-stack web application for managing employees, companies, and admin operations. Built with Node.js, Express.js, MongoDB, EJS, and a custom color palette for a beautiful UI.

---

## Features
- Employee registration, login, dashboard, and resume management
- Company registration, login, dashboard, job posting, and candidate search
- Admin login (default: admin/admin), dashboard to manage employees and companies
- Modern, responsive UI with a custom color palette

---

## Prerequisites

Before you begin, make sure you have the following installed on your system:

1. **Node.js** (v16 or later recommended)
   - Download and install from: https://nodejs.org/
2. **npm** (comes with Node.js)
3. **MongoDB** (Community Edition)
   - Download and install from: https://www.mongodb.com/try/download/community
   - After installation, start the MongoDB server:
     - On Windows: Open Command Prompt and run: `mongod`
     - On Mac/Linux: Run: `mongod` in your terminal

---

## Getting Started

1. **Clone or Download the Repository**
   - Place the project folder (`manage corp`) on your machine.

2. **Install Dependencies**
   - Open a terminal in the project directory and run:
     ```sh
     npm install
     ```

3. **Configure Environment (Optional)**
   - By default, the app connects to MongoDB at `mongodb://localhost:27017/managecorp`.
   - To use a different MongoDB URI, create a `.env` file in the root folder and add:
     ```env
     MONGO_URI=your_mongodb_connection_string
     ```

4. **Start MongoDB**
   - Make sure your MongoDB server is running (see Prerequisites above).

5. **Run the Application**
   - In the terminal, run:
     ```sh
     node app.js
     ```
   - The server will start on `http://localhost:3000`

6. **Access the App**
   - Open your browser and go to: [http://localhost:3000](http://localhost:3000)

---

## Default Admin Credentials
- **Username:** `admin`
- **Password:** `admin`

These credentials are hardcoded for demo/testing. You can log in as admin even if no admin user exists in the database.

---

## Project Structure
```
manage corp/
├── app.js
├── package.json
├── public/
│   └── style.css
├── models/
│   ├── Admin.js
│   ├── Company.js
│   └── Employee.js
├── routes/
│   ├── admin.js
│   ├── company.js
│   ├── employee.js
│   └── main.js
├── views/
│   ├── index.ejs
│   ├── layout.ejs
│   ├── ...
└── README.md
```

---

## Troubleshooting
- **MongoDB not found?**
  - Make sure MongoDB is installed and running (`mongod`).
- **Port already in use?**
  - Change the port in `app.js` or stop the other process using the port.
- **Cannot connect to MongoDB?**
  - Check your connection string and that MongoDB is running.

---

## Customization
- The color palette is set in `public/style.css` using CSS variables.
- You can change the palette or UI by editing the CSS and EJS files.

---

## License
This project is for educational/demo purposes.
